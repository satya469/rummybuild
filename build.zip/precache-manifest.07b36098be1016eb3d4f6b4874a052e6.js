self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b69c673b95bcbd8071afb7cf5f1ac8a5",
    "url": "/index.html"
  },
  {
    "revision": "1c9db72dd5fcb0fb291c",
    "url": "/static/css/10.834d426e.chunk.css"
  },
  {
    "revision": "112f684e55112f73b6d7",
    "url": "/static/css/12.3e68da18.chunk.css"
  },
  {
    "revision": "0a838b34ec278eb63d5c",
    "url": "/static/css/7.2e947bf2.chunk.css"
  },
  {
    "revision": "d36646fffa536cfed0a8",
    "url": "/static/css/9.d6ada732.chunk.css"
  },
  {
    "revision": "1e70f3007d38d5dc2ef3",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "218e3eca6313956d30c8",
    "url": "/static/js/0.82418cb4.chunk.js"
  },
  {
    "revision": "732ebce2d4a7a70460a8",
    "url": "/static/js/1.5937d372.chunk.js"
  },
  {
    "revision": "1c9db72dd5fcb0fb291c",
    "url": "/static/js/10.d7c2f17a.chunk.js"
  },
  {
    "revision": "02340ec82a72c9212038",
    "url": "/static/js/11.d810a002.chunk.js"
  },
  {
    "revision": "112f684e55112f73b6d7",
    "url": "/static/js/12.917c0d46.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/12.917c0d46.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ef2c348b1492b7c10851",
    "url": "/static/js/13.f746ce69.chunk.js"
  },
  {
    "revision": "f288914b65cbafd58faf",
    "url": "/static/js/14.7ad37bee.chunk.js"
  },
  {
    "revision": "7366d6a15cbeb2d5274f",
    "url": "/static/js/15.e6ee774d.chunk.js"
  },
  {
    "revision": "6bf3be9aa747481b2266",
    "url": "/static/js/16.65b0a16b.chunk.js"
  },
  {
    "revision": "49abe43a9b2d3cfe7ab7",
    "url": "/static/js/17.3644b712.chunk.js"
  },
  {
    "revision": "370a2b565a10348935ce",
    "url": "/static/js/18.ef16d053.chunk.js"
  },
  {
    "revision": "0743c7c698f86a0f30c0",
    "url": "/static/js/19.ef462033.chunk.js"
  },
  {
    "revision": "1a4ae8bef9506b8cb0dd",
    "url": "/static/js/2.9d644daa.chunk.js"
  },
  {
    "revision": "94b64829502c7cc14465",
    "url": "/static/js/20.2497f406.chunk.js"
  },
  {
    "revision": "8c4ff5bb5536aad2074f",
    "url": "/static/js/21.e3f7d360.chunk.js"
  },
  {
    "revision": "0c6d25bae239c7d3c78b",
    "url": "/static/js/22.6e240145.chunk.js"
  },
  {
    "revision": "25b7530a352169f3c71d",
    "url": "/static/js/23.2ee93eb8.chunk.js"
  },
  {
    "revision": "5fbaa0aef381bde6a31a",
    "url": "/static/js/24.b81afc5f.chunk.js"
  },
  {
    "revision": "24f421d73da836419adb",
    "url": "/static/js/25.96448a92.chunk.js"
  },
  {
    "revision": "5670fc0db566950b2443",
    "url": "/static/js/26.db32b075.chunk.js"
  },
  {
    "revision": "bd9b78646b03052ef2cc",
    "url": "/static/js/27.23ebcb8d.chunk.js"
  },
  {
    "revision": "56985abb058f8a8420ee",
    "url": "/static/js/28.c182fc02.chunk.js"
  },
  {
    "revision": "54c2f91f58cf99f3d10c",
    "url": "/static/js/29.3947a3a0.chunk.js"
  },
  {
    "revision": "8695558adf3be7bb683e",
    "url": "/static/js/3.1da8750a.chunk.js"
  },
  {
    "revision": "72264b737db8170ce4a5",
    "url": "/static/js/30.185abb13.chunk.js"
  },
  {
    "revision": "1394011a7eea921e78f2",
    "url": "/static/js/31.07a8727c.chunk.js"
  },
  {
    "revision": "117cda1c575f07340736",
    "url": "/static/js/32.2be6595d.chunk.js"
  },
  {
    "revision": "7d85f6d25047f89c9313",
    "url": "/static/js/33.0f87c5fa.chunk.js"
  },
  {
    "revision": "40439cc9164837a68888",
    "url": "/static/js/34.628c00bc.chunk.js"
  },
  {
    "revision": "79a7d9660c7c9e586e8a",
    "url": "/static/js/35.590211d6.chunk.js"
  },
  {
    "revision": "4126a910160999ba036a",
    "url": "/static/js/36.d5070096.chunk.js"
  },
  {
    "revision": "64d80a9230795c498f6f",
    "url": "/static/js/37.2d479c6d.chunk.js"
  },
  {
    "revision": "5cbbb31cf2bcf507b144",
    "url": "/static/js/38.05c2a9e1.chunk.js"
  },
  {
    "revision": "f655a1d8af2d9061670f",
    "url": "/static/js/39.caf5d5fd.chunk.js"
  },
  {
    "revision": "6bb665f0493ecd38ac7f",
    "url": "/static/js/4.887ea5ba.chunk.js"
  },
  {
    "revision": "9ad8b53aa2b4df3030c4",
    "url": "/static/js/40.be9af3e9.chunk.js"
  },
  {
    "revision": "172f213b2d7aa302228f",
    "url": "/static/js/41.fc2b3060.chunk.js"
  },
  {
    "revision": "0dc52fd822de9ebea552",
    "url": "/static/js/42.05aa1439.chunk.js"
  },
  {
    "revision": "2446ba70cc0e7b580ac5",
    "url": "/static/js/43.4d12dc48.chunk.js"
  },
  {
    "revision": "c9813b3bbfbe0c56050e",
    "url": "/static/js/44.fc80e313.chunk.js"
  },
  {
    "revision": "43782dfb50a86e7883b8",
    "url": "/static/js/45.3f541d57.chunk.js"
  },
  {
    "revision": "a141a135dc5dedc3fe2b",
    "url": "/static/js/46.f2b04201.chunk.js"
  },
  {
    "revision": "ad1c39359d51bd2c1885",
    "url": "/static/js/47.8f6dcd66.chunk.js"
  },
  {
    "revision": "f1d5c8376118a5f22c27",
    "url": "/static/js/48.124e11d5.chunk.js"
  },
  {
    "revision": "0986b206169ce6ace132",
    "url": "/static/js/49.938afdec.chunk.js"
  },
  {
    "revision": "0a838b34ec278eb63d5c",
    "url": "/static/js/7.f9f5202a.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/7.f9f5202a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "eadf851757a530ec9eb9",
    "url": "/static/js/8.deb82853.chunk.js"
  },
  {
    "revision": "d36646fffa536cfed0a8",
    "url": "/static/js/9.458d133c.chunk.js"
  },
  {
    "revision": "1e70f3007d38d5dc2ef3",
    "url": "/static/js/main.7bdadc29.chunk.js"
  },
  {
    "revision": "2922d38cad4fa23d9e98",
    "url": "/static/js/runtime-main.99b444a1.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);