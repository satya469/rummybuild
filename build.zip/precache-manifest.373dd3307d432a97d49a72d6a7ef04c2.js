self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0cef6b71a66f63e956bb802fb4b5f326",
    "url": "/index.html"
  },
  {
    "revision": "12733bc7914e930f00e1",
    "url": "/static/css/10.834d426e.chunk.css"
  },
  {
    "revision": "97a6de5146f71a0c8202",
    "url": "/static/css/12.3e68da18.chunk.css"
  },
  {
    "revision": "243bafbbab3acb9812b8",
    "url": "/static/css/7.2e947bf2.chunk.css"
  },
  {
    "revision": "bb7dbe80566d719230f1",
    "url": "/static/css/9.d6ada732.chunk.css"
  },
  {
    "revision": "5ae8531a8c958bdf27aa",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "218e3eca6313956d30c8",
    "url": "/static/js/0.82418cb4.chunk.js"
  },
  {
    "revision": "fde973dece308bee6b61",
    "url": "/static/js/1.0bdc3d69.chunk.js"
  },
  {
    "revision": "12733bc7914e930f00e1",
    "url": "/static/js/10.87bb8d9a.chunk.js"
  },
  {
    "revision": "4037ccbe4dc438ce3906",
    "url": "/static/js/11.ad0fe74b.chunk.js"
  },
  {
    "revision": "97a6de5146f71a0c8202",
    "url": "/static/js/12.6b12353d.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/12.6b12353d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "82b7fd5230f23a73c15f",
    "url": "/static/js/13.a1d4f08b.chunk.js"
  },
  {
    "revision": "ba7056c0ca63efbdfa6d",
    "url": "/static/js/14.7981c535.chunk.js"
  },
  {
    "revision": "d11e0889e4a772fed085",
    "url": "/static/js/15.561fc76b.chunk.js"
  },
  {
    "revision": "de0cd56116d7171d57a8",
    "url": "/static/js/16.f4268c28.chunk.js"
  },
  {
    "revision": "f57e6c6667265f1e3fdd",
    "url": "/static/js/17.5ca1baaa.chunk.js"
  },
  {
    "revision": "2788b0f5030dff1d266f",
    "url": "/static/js/18.8483383a.chunk.js"
  },
  {
    "revision": "bc8099a71acb281dcc96",
    "url": "/static/js/19.1f66ac5a.chunk.js"
  },
  {
    "revision": "3820aec29f8a96bf8666",
    "url": "/static/js/2.ef4c432d.chunk.js"
  },
  {
    "revision": "d224bdb8004f3b37500a",
    "url": "/static/js/20.5e04e949.chunk.js"
  },
  {
    "revision": "f59fcf3df18177a85ff7",
    "url": "/static/js/21.0e4441f0.chunk.js"
  },
  {
    "revision": "6e57fc741eaacd51d506",
    "url": "/static/js/22.39d5ec17.chunk.js"
  },
  {
    "revision": "06406c8b6601832b8810",
    "url": "/static/js/23.27601411.chunk.js"
  },
  {
    "revision": "8ae0f348626d7a91905e",
    "url": "/static/js/24.49886ef2.chunk.js"
  },
  {
    "revision": "26f77b3ec77f0c208727",
    "url": "/static/js/25.850115f1.chunk.js"
  },
  {
    "revision": "f2a102e2228346350fe3",
    "url": "/static/js/26.5dc73035.chunk.js"
  },
  {
    "revision": "ab64c07155a25dc12efe",
    "url": "/static/js/27.5b96d39a.chunk.js"
  },
  {
    "revision": "a67fe0d1f07783ec77b1",
    "url": "/static/js/28.894400ce.chunk.js"
  },
  {
    "revision": "a2f2c076d8b5cb647d22",
    "url": "/static/js/29.23dccc88.chunk.js"
  },
  {
    "revision": "8695558adf3be7bb683e",
    "url": "/static/js/3.1da8750a.chunk.js"
  },
  {
    "revision": "f44c4f23846616524dd0",
    "url": "/static/js/30.865b0ef0.chunk.js"
  },
  {
    "revision": "7d755674970f12c1ce06",
    "url": "/static/js/31.08c2125b.chunk.js"
  },
  {
    "revision": "bae49f7a1bd4b9a341fe",
    "url": "/static/js/32.96f50a8d.chunk.js"
  },
  {
    "revision": "40cd60aff01b8537c99c",
    "url": "/static/js/33.533f2ffc.chunk.js"
  },
  {
    "revision": "d8c1e216491d42a1d46f",
    "url": "/static/js/34.34c35c8d.chunk.js"
  },
  {
    "revision": "c5f77922cf735cb1abc6",
    "url": "/static/js/35.1a9dd189.chunk.js"
  },
  {
    "revision": "af87ddd6d78d63a9ceb9",
    "url": "/static/js/36.97893da4.chunk.js"
  },
  {
    "revision": "8a05aa999de30eb94a3b",
    "url": "/static/js/37.7cf1ca7c.chunk.js"
  },
  {
    "revision": "685f29a6fb66d00668d0",
    "url": "/static/js/38.68321fdb.chunk.js"
  },
  {
    "revision": "b9217a783a4e195d5751",
    "url": "/static/js/39.3353b437.chunk.js"
  },
  {
    "revision": "72c2a810d62549757cdd",
    "url": "/static/js/4.7e70649e.chunk.js"
  },
  {
    "revision": "9ad8b53aa2b4df3030c4",
    "url": "/static/js/40.be9af3e9.chunk.js"
  },
  {
    "revision": "e00a5036166ce576b784",
    "url": "/static/js/41.571185e0.chunk.js"
  },
  {
    "revision": "eae5afd447928bff73c0",
    "url": "/static/js/42.2d33d6b1.chunk.js"
  },
  {
    "revision": "a303b482d11f3d8f0359",
    "url": "/static/js/43.b6cdf56b.chunk.js"
  },
  {
    "revision": "4a09272d72999c38a717",
    "url": "/static/js/44.227f353a.chunk.js"
  },
  {
    "revision": "6bdbff3cf3d30600bdad",
    "url": "/static/js/45.1e77108f.chunk.js"
  },
  {
    "revision": "e7271d5bc3927545673e",
    "url": "/static/js/46.fbb2d80f.chunk.js"
  },
  {
    "revision": "904aa6d65e5906c15a23",
    "url": "/static/js/47.99233564.chunk.js"
  },
  {
    "revision": "bade0b2fbe7e6ab90dba",
    "url": "/static/js/48.f08546ac.chunk.js"
  },
  {
    "revision": "3636e037b9712aa48c7a",
    "url": "/static/js/49.cba706e8.chunk.js"
  },
  {
    "revision": "243bafbbab3acb9812b8",
    "url": "/static/js/7.ace5cd8c.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/7.ace5cd8c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e613b2a464da8f4e16a9",
    "url": "/static/js/8.24b13ecc.chunk.js"
  },
  {
    "revision": "bb7dbe80566d719230f1",
    "url": "/static/js/9.3dbc9cb9.chunk.js"
  },
  {
    "revision": "5ae8531a8c958bdf27aa",
    "url": "/static/js/main.185053a4.chunk.js"
  },
  {
    "revision": "2d152ba9bd5cbf8720a3",
    "url": "/static/js/runtime-main.11b6c0ed.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);