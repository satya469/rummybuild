self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "60bfd827e85e16348674c1921d3260a5",
    "url": "/index.html"
  },
  {
    "revision": "fc306d006478f8d04241",
    "url": "/static/css/10.834d426e.chunk.css"
  },
  {
    "revision": "2c146b469fa65df6a32d",
    "url": "/static/css/12.3e68da18.chunk.css"
  },
  {
    "revision": "df48926fc06dcd9cb5cb",
    "url": "/static/css/7.2e947bf2.chunk.css"
  },
  {
    "revision": "256efdb730563c296c21",
    "url": "/static/css/9.9d3ee8f2.chunk.css"
  },
  {
    "revision": "e43d8a18b32d09ecf447",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "c68846ff146863a9c2b0",
    "url": "/static/js/0.72d7d6be.chunk.js"
  },
  {
    "revision": "eedf5957a7f025cffdec",
    "url": "/static/js/1.d3c080b4.chunk.js"
  },
  {
    "revision": "fc306d006478f8d04241",
    "url": "/static/js/10.4a84e8d5.chunk.js"
  },
  {
    "revision": "d21770a837a7b8becddd",
    "url": "/static/js/11.3312c1a5.chunk.js"
  },
  {
    "revision": "2c146b469fa65df6a32d",
    "url": "/static/js/12.7c0ceeee.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/12.7c0ceeee.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8ac0962367f266624467",
    "url": "/static/js/13.f3bb1970.chunk.js"
  },
  {
    "revision": "624991b5ec968a8d1c19",
    "url": "/static/js/14.100ec1c6.chunk.js"
  },
  {
    "revision": "c96d9b478d1f35c8b30d",
    "url": "/static/js/15.08adf53d.chunk.js"
  },
  {
    "revision": "1b0b7fd52e76b4ba50d7",
    "url": "/static/js/16.1e9bda20.chunk.js"
  },
  {
    "revision": "f2a8fbf5614d54566ae6",
    "url": "/static/js/17.c48c8877.chunk.js"
  },
  {
    "revision": "56fd2f19d91e50d6ebfe",
    "url": "/static/js/18.823bd0ce.chunk.js"
  },
  {
    "revision": "cec13439da6f0e820d1a",
    "url": "/static/js/19.ce9f5427.chunk.js"
  },
  {
    "revision": "93a73e5f924b827ea6ba",
    "url": "/static/js/2.b1591c26.chunk.js"
  },
  {
    "revision": "07e53f706c7b9cccc047",
    "url": "/static/js/20.a0e7e04a.chunk.js"
  },
  {
    "revision": "fb0336f68e3f10079e56",
    "url": "/static/js/21.032d61c4.chunk.js"
  },
  {
    "revision": "21cfff65e6a81aba2055",
    "url": "/static/js/22.9a3d721f.chunk.js"
  },
  {
    "revision": "dab430dc6510231089d4",
    "url": "/static/js/23.308b2510.chunk.js"
  },
  {
    "revision": "b88897024de795bd2862",
    "url": "/static/js/24.c882cd82.chunk.js"
  },
  {
    "revision": "95517b69380cdf8cf508",
    "url": "/static/js/25.0c42c0fa.chunk.js"
  },
  {
    "revision": "0757eaa19df4c915db5e",
    "url": "/static/js/26.1f79eb7d.chunk.js"
  },
  {
    "revision": "7adb06d6487d3e7e04a2",
    "url": "/static/js/27.88dfbe51.chunk.js"
  },
  {
    "revision": "a467184b0f05ac205e01",
    "url": "/static/js/28.a62cfb4d.chunk.js"
  },
  {
    "revision": "2dd2ba8699b4a06b8ce8",
    "url": "/static/js/29.58981d65.chunk.js"
  },
  {
    "revision": "58a37475c3525d46ef57",
    "url": "/static/js/3.907ddb1e.chunk.js"
  },
  {
    "revision": "150093a27dc038ebd835",
    "url": "/static/js/30.c46c1e8d.chunk.js"
  },
  {
    "revision": "35173f20056ba9b5e70c",
    "url": "/static/js/31.8b599fe9.chunk.js"
  },
  {
    "revision": "226c165acb6ac32558fb",
    "url": "/static/js/32.f254a49d.chunk.js"
  },
  {
    "revision": "7eb2db8a352522e7dfd1",
    "url": "/static/js/33.65a38119.chunk.js"
  },
  {
    "revision": "13fc35b8ee4a5fc4a5c8",
    "url": "/static/js/34.b804d1f7.chunk.js"
  },
  {
    "revision": "260a64f02f066b59130c",
    "url": "/static/js/35.0eb27633.chunk.js"
  },
  {
    "revision": "291f40aafda0313c16be",
    "url": "/static/js/36.20cf7217.chunk.js"
  },
  {
    "revision": "a4860925e3e94e43b21d",
    "url": "/static/js/37.0ce8e638.chunk.js"
  },
  {
    "revision": "2d94ee1e0775496cbc39",
    "url": "/static/js/38.7aacbb25.chunk.js"
  },
  {
    "revision": "5ede532f1bf07e412ff1",
    "url": "/static/js/39.1e5f1c2f.chunk.js"
  },
  {
    "revision": "ad4c99d19fea5288ca3b",
    "url": "/static/js/4.ec06ba3c.chunk.js"
  },
  {
    "revision": "0cf15a212e62c0015d70",
    "url": "/static/js/40.76942d4b.chunk.js"
  },
  {
    "revision": "843dbe8938b85996458c",
    "url": "/static/js/41.72904723.chunk.js"
  },
  {
    "revision": "2eec5847f9352a7576e2",
    "url": "/static/js/42.1accbedf.chunk.js"
  },
  {
    "revision": "0f7191ef00779ed46fbb",
    "url": "/static/js/43.0df62621.chunk.js"
  },
  {
    "revision": "0bee8bf1d7cd364b2363",
    "url": "/static/js/44.2025eeee.chunk.js"
  },
  {
    "revision": "ce47e9ff87fd3330647d",
    "url": "/static/js/45.ca2a2400.chunk.js"
  },
  {
    "revision": "a2010f2191f0ab44674e",
    "url": "/static/js/46.a78a3d48.chunk.js"
  },
  {
    "revision": "0e8061af7cb27399268c",
    "url": "/static/js/47.1f99d7bd.chunk.js"
  },
  {
    "revision": "1416d24306711ffee4e9",
    "url": "/static/js/48.209b6b65.chunk.js"
  },
  {
    "revision": "98a191773495e5837da0",
    "url": "/static/js/49.1bd4b16e.chunk.js"
  },
  {
    "revision": "df48926fc06dcd9cb5cb",
    "url": "/static/js/7.59449456.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/7.59449456.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f80843112fc4fac46417",
    "url": "/static/js/8.fc58b206.chunk.js"
  },
  {
    "revision": "256efdb730563c296c21",
    "url": "/static/js/9.bdcf61c7.chunk.js"
  },
  {
    "revision": "e43d8a18b32d09ecf447",
    "url": "/static/js/main.605539d3.chunk.js"
  },
  {
    "revision": "5f2c7d51ea17c1130594",
    "url": "/static/js/runtime-main.c86979b1.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);