self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "026f918bb278b13bb711f21c4c3bf3ad",
    "url": "/index.html"
  },
  {
    "revision": "fc306d006478f8d04241",
    "url": "/static/css/10.834d426e.chunk.css"
  },
  {
    "revision": "948b88edee1c6b728560",
    "url": "/static/css/12.3e68da18.chunk.css"
  },
  {
    "revision": "c0c8ad1be08c2b35169a",
    "url": "/static/css/7.2e947bf2.chunk.css"
  },
  {
    "revision": "9ff863a7bdf1f0eed1d8",
    "url": "/static/css/9.9d3ee8f2.chunk.css"
  },
  {
    "revision": "353a0921c4bfa0e15346",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "c68846ff146863a9c2b0",
    "url": "/static/js/0.72d7d6be.chunk.js"
  },
  {
    "revision": "17ab43c5a0b862ec2382",
    "url": "/static/js/1.dda65210.chunk.js"
  },
  {
    "revision": "fc306d006478f8d04241",
    "url": "/static/js/10.4a84e8d5.chunk.js"
  },
  {
    "revision": "d9a572ef935fb3e1464b",
    "url": "/static/js/11.92b6b6b0.chunk.js"
  },
  {
    "revision": "948b88edee1c6b728560",
    "url": "/static/js/12.77e3dca1.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/12.77e3dca1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "826ab4f5c664ce23b423",
    "url": "/static/js/13.4cc9e618.chunk.js"
  },
  {
    "revision": "4a3efa9f0c6815c24db9",
    "url": "/static/js/14.c4617b61.chunk.js"
  },
  {
    "revision": "5b094a2578ada462f5b3",
    "url": "/static/js/15.a6a44643.chunk.js"
  },
  {
    "revision": "0cabbf42a333484def69",
    "url": "/static/js/16.e85c6c2a.chunk.js"
  },
  {
    "revision": "fa5f19a3f7c86c64b87a",
    "url": "/static/js/17.dfaf8725.chunk.js"
  },
  {
    "revision": "60c39474497dd5d0bd6a",
    "url": "/static/js/18.2e5aabb0.chunk.js"
  },
  {
    "revision": "f2ae601ef274b9a05e28",
    "url": "/static/js/19.8403821d.chunk.js"
  },
  {
    "revision": "4aac6a4306eace2f0ccd",
    "url": "/static/js/2.761f3d36.chunk.js"
  },
  {
    "revision": "0c7d14cc3d941e8e46fd",
    "url": "/static/js/20.7d4319da.chunk.js"
  },
  {
    "revision": "7a1a6595aff97369d5ff",
    "url": "/static/js/21.6c9264f2.chunk.js"
  },
  {
    "revision": "5aebe12efe57eb57ce76",
    "url": "/static/js/22.d055d3fb.chunk.js"
  },
  {
    "revision": "7a5e42f6efac7db8dd7e",
    "url": "/static/js/23.2f731af7.chunk.js"
  },
  {
    "revision": "b1808a630b1270733aa0",
    "url": "/static/js/24.23825237.chunk.js"
  },
  {
    "revision": "44dd98d8f560cfd0dba4",
    "url": "/static/js/25.a8b5608b.chunk.js"
  },
  {
    "revision": "2940c62cc7f75826ccca",
    "url": "/static/js/26.721389e5.chunk.js"
  },
  {
    "revision": "ec6cf0999fec5a380839",
    "url": "/static/js/27.d78dd31b.chunk.js"
  },
  {
    "revision": "4be3e2efb7b31d0aafb2",
    "url": "/static/js/28.fd50f0b3.chunk.js"
  },
  {
    "revision": "7f529bd3fb649b09aed1",
    "url": "/static/js/29.27bb811e.chunk.js"
  },
  {
    "revision": "58a37475c3525d46ef57",
    "url": "/static/js/3.907ddb1e.chunk.js"
  },
  {
    "revision": "007b087d664fccb7cc27",
    "url": "/static/js/30.66cbddad.chunk.js"
  },
  {
    "revision": "2407b3e1e23dad2d5d0d",
    "url": "/static/js/31.4e7ff4b9.chunk.js"
  },
  {
    "revision": "515df4bee0b3ac0f6d50",
    "url": "/static/js/32.4bc354ca.chunk.js"
  },
  {
    "revision": "3dce686dde3fd42f83e9",
    "url": "/static/js/33.448a2d9a.chunk.js"
  },
  {
    "revision": "c7f8b4a55bc8505b5244",
    "url": "/static/js/34.8a487f95.chunk.js"
  },
  {
    "revision": "ac46d3305a537aea6441",
    "url": "/static/js/35.c095660b.chunk.js"
  },
  {
    "revision": "23eb9d02ca5ad2e138af",
    "url": "/static/js/36.dec7090b.chunk.js"
  },
  {
    "revision": "0da57bfe3ffe8e86c7c7",
    "url": "/static/js/37.80e6b188.chunk.js"
  },
  {
    "revision": "cb3796e61576245f2959",
    "url": "/static/js/38.280db0e2.chunk.js"
  },
  {
    "revision": "2c06bf6d7ce371d6f610",
    "url": "/static/js/39.aca37a0c.chunk.js"
  },
  {
    "revision": "92eb0b2cd53781f00836",
    "url": "/static/js/4.694e30b7.chunk.js"
  },
  {
    "revision": "0cf15a212e62c0015d70",
    "url": "/static/js/40.76942d4b.chunk.js"
  },
  {
    "revision": "dd6814874d4b6113993d",
    "url": "/static/js/41.fa19bf43.chunk.js"
  },
  {
    "revision": "a51b451c444123c986a8",
    "url": "/static/js/42.dc65e3a0.chunk.js"
  },
  {
    "revision": "451e65a8739beefb413a",
    "url": "/static/js/43.b897a741.chunk.js"
  },
  {
    "revision": "98336386b99062d42954",
    "url": "/static/js/44.0860031e.chunk.js"
  },
  {
    "revision": "075292d4713c3c12de4d",
    "url": "/static/js/45.30dca6a4.chunk.js"
  },
  {
    "revision": "bd0f7bd23e67119de877",
    "url": "/static/js/46.6c3f11d6.chunk.js"
  },
  {
    "revision": "41de447472868dfe50b7",
    "url": "/static/js/47.fd05a424.chunk.js"
  },
  {
    "revision": "968e815194ae80b09840",
    "url": "/static/js/48.51393efd.chunk.js"
  },
  {
    "revision": "690c754c9f64a5905363",
    "url": "/static/js/49.517c2ec6.chunk.js"
  },
  {
    "revision": "c0c8ad1be08c2b35169a",
    "url": "/static/js/7.f7db307a.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/7.f7db307a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3254a07c8958639ecb8b",
    "url": "/static/js/8.350e723e.chunk.js"
  },
  {
    "revision": "9ff863a7bdf1f0eed1d8",
    "url": "/static/js/9.1808cc58.chunk.js"
  },
  {
    "revision": "353a0921c4bfa0e15346",
    "url": "/static/js/main.1ac65690.chunk.js"
  },
  {
    "revision": "029bb76f9aab926b5264",
    "url": "/static/js/runtime-main.d0e8df08.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);