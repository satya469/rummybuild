self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3d804a96c59ed5a02eb459b6f153c6ea",
    "url": "/index.html"
  },
  {
    "revision": "1c9db72dd5fcb0fb291c",
    "url": "/static/css/10.834d426e.chunk.css"
  },
  {
    "revision": "96cac1fd23cedf660092",
    "url": "/static/css/12.3e68da18.chunk.css"
  },
  {
    "revision": "6e7f131805d51e48b095",
    "url": "/static/css/7.2e947bf2.chunk.css"
  },
  {
    "revision": "13dd7f1c9a158d814e97",
    "url": "/static/css/9.d6ada732.chunk.css"
  },
  {
    "revision": "3c5f1a87171c9bb77864",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "218e3eca6313956d30c8",
    "url": "/static/js/0.82418cb4.chunk.js"
  },
  {
    "revision": "93c087768ef80bae3390",
    "url": "/static/js/1.d5477765.chunk.js"
  },
  {
    "revision": "1c9db72dd5fcb0fb291c",
    "url": "/static/js/10.d7c2f17a.chunk.js"
  },
  {
    "revision": "a00708f0abffabc3df16",
    "url": "/static/js/11.2828d55c.chunk.js"
  },
  {
    "revision": "96cac1fd23cedf660092",
    "url": "/static/js/12.79033c95.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/12.79033c95.chunk.js.LICENSE.txt"
  },
  {
    "revision": "664bf63cf3a7888e82e6",
    "url": "/static/js/13.64ad2799.chunk.js"
  },
  {
    "revision": "2ac65206063cdd8cc246",
    "url": "/static/js/14.7fafce26.chunk.js"
  },
  {
    "revision": "c4e3b121622571d40712",
    "url": "/static/js/15.9e257982.chunk.js"
  },
  {
    "revision": "363f5f66f51d7ef7edd5",
    "url": "/static/js/16.57458be1.chunk.js"
  },
  {
    "revision": "689664091cdae6147f9a",
    "url": "/static/js/17.f3ea3786.chunk.js"
  },
  {
    "revision": "fb3316c7a41652273446",
    "url": "/static/js/18.8e1bc6a9.chunk.js"
  },
  {
    "revision": "b61eb6e7d94dd8bc62ba",
    "url": "/static/js/19.8315774e.chunk.js"
  },
  {
    "revision": "e00ecdb2827a2fc94b44",
    "url": "/static/js/2.6cdd2332.chunk.js"
  },
  {
    "revision": "725a86f376db71e43d9d",
    "url": "/static/js/20.647906b1.chunk.js"
  },
  {
    "revision": "04f3ade5924f825203b7",
    "url": "/static/js/21.055e22a0.chunk.js"
  },
  {
    "revision": "74f138df9bc4a2721452",
    "url": "/static/js/22.171337c8.chunk.js"
  },
  {
    "revision": "02513894f01dc2f90b22",
    "url": "/static/js/23.2e93f6bf.chunk.js"
  },
  {
    "revision": "ec53e69e5b42a25c4396",
    "url": "/static/js/24.a95d507d.chunk.js"
  },
  {
    "revision": "f72c92f37cb3ca9b4d76",
    "url": "/static/js/25.438d0685.chunk.js"
  },
  {
    "revision": "493d7ae55894f1793881",
    "url": "/static/js/26.b1706135.chunk.js"
  },
  {
    "revision": "022639ea3220d3364856",
    "url": "/static/js/27.f5101394.chunk.js"
  },
  {
    "revision": "3c2f455e77795d42b0ef",
    "url": "/static/js/28.3e08e6eb.chunk.js"
  },
  {
    "revision": "e19d2b574f9c683659d2",
    "url": "/static/js/29.e0dfaeee.chunk.js"
  },
  {
    "revision": "8695558adf3be7bb683e",
    "url": "/static/js/3.1da8750a.chunk.js"
  },
  {
    "revision": "05e70cbe9847f5790cea",
    "url": "/static/js/30.8c502b3a.chunk.js"
  },
  {
    "revision": "2bf4949995599f3dd1d1",
    "url": "/static/js/31.120ad558.chunk.js"
  },
  {
    "revision": "9c33cc093be4dbaca67f",
    "url": "/static/js/32.fc3d4b9a.chunk.js"
  },
  {
    "revision": "d462dfb3d5eed2f88150",
    "url": "/static/js/33.e5daa5f6.chunk.js"
  },
  {
    "revision": "301cf8012f5b59ce0979",
    "url": "/static/js/34.dbe24a31.chunk.js"
  },
  {
    "revision": "ac847bacd3740d2c5e38",
    "url": "/static/js/35.d795949e.chunk.js"
  },
  {
    "revision": "08cd31c6328edb4b8808",
    "url": "/static/js/36.fe09ed3c.chunk.js"
  },
  {
    "revision": "fbb74b7d9ff44c7f9a76",
    "url": "/static/js/37.6860d8e9.chunk.js"
  },
  {
    "revision": "732f3559e1eaff92daea",
    "url": "/static/js/38.98387258.chunk.js"
  },
  {
    "revision": "68992a6e89e1178e3a1c",
    "url": "/static/js/39.d574ad23.chunk.js"
  },
  {
    "revision": "9b03c903ea490502fa87",
    "url": "/static/js/4.fa0b5ffc.chunk.js"
  },
  {
    "revision": "9ad8b53aa2b4df3030c4",
    "url": "/static/js/40.be9af3e9.chunk.js"
  },
  {
    "revision": "8b41a0650021e89a3178",
    "url": "/static/js/41.39d6ef10.chunk.js"
  },
  {
    "revision": "11e26ff70bdced158eb6",
    "url": "/static/js/42.d849f51a.chunk.js"
  },
  {
    "revision": "00d56f58283b2c2489fb",
    "url": "/static/js/43.676ffd27.chunk.js"
  },
  {
    "revision": "0424ebade4169f9bcc6f",
    "url": "/static/js/44.307ab225.chunk.js"
  },
  {
    "revision": "8d94b52f753a9972941c",
    "url": "/static/js/45.2cfe7fb9.chunk.js"
  },
  {
    "revision": "301d237bd1a5954baed8",
    "url": "/static/js/46.17a83cf8.chunk.js"
  },
  {
    "revision": "6f8c3919d93001e4951e",
    "url": "/static/js/47.9553f903.chunk.js"
  },
  {
    "revision": "555603451bc6fe97717b",
    "url": "/static/js/48.7b55a996.chunk.js"
  },
  {
    "revision": "21265c39a2c7a9abcd38",
    "url": "/static/js/49.38a98e91.chunk.js"
  },
  {
    "revision": "6e7f131805d51e48b095",
    "url": "/static/js/7.8e38f760.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/7.8e38f760.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9dffe939a223cffa0cb4",
    "url": "/static/js/8.f9127ae8.chunk.js"
  },
  {
    "revision": "13dd7f1c9a158d814e97",
    "url": "/static/js/9.a27c2574.chunk.js"
  },
  {
    "revision": "3c5f1a87171c9bb77864",
    "url": "/static/js/main.d2fa24af.chunk.js"
  },
  {
    "revision": "54f520ba38adf3df6b3f",
    "url": "/static/js/runtime-main.ac03dfe8.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);